insert into users (username, first_name, last_name) values (rahmat_digital_skola, rahmat, hidayat);
insert into users (username, first_name, last_name) values (lela_digital_skola, lela, sari);
insert into users (username, first_name, last_name) values (kurniawan_digital_skola, kurniawan, agung);
insert into users (username, first_name, last_name) values (adam_digital_skola, adam, makmur);
insert into users (username, first_name, last_name) values (dito_digital_skola, dito, setyadhi);
insert into users (username, first_name, last_name) values (kendrick_digital_skola, kendrick, lamar);