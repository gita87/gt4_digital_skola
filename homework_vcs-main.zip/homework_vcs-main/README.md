# Homework Version Control System
This repo to used do homework student Data Scientist Class - Digital Skola

### Please Do !
- Clone this repo : https://github.com/rahmatdigitalskola/homework_vcs.git

- Add 2 new Column : first_name and last_name
in file schema.sql

- Insert some data in schema.sql
with file db.sql 

